import React, { useState } from 'react';
import { 
  Sparkles, 
  Plus, 
  Trash2, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  Award, 
  Layers, 
  BookOpen, 
  HelpCircle, 
  Link2, 
  Check, 
  ArrowRight,
  ArrowLeft,
  ListOrdered,
  FileQuestion,
  FileText,
  Eye,
  Edit3,
  Settings,
  Pencil,
  Upload,
  Image as ImageIcon,
  FileUp,
  X,
  Maximize2,
  Cpu,
  Server,
  Database,
  Lock,
  Shield,
  Palette
} from 'lucide-react';
import { 
  getActiveQuizDatabase, 
  saveQuizToStorage, 
  addQuestionToQuizStorage, 
  updateQuestionInQuizStorage,
  updateQuizMetadataStorage,
  deleteQuestionFromQuizStorage, 
  resetQuizDatabaseToDefaults 
} from '../data/quizDatabase';
import QuizDiagram from './QuizDiagram';

const QUESTION_TYPES = [
  { id: 'multiple_choice', label: 'Kahoot 4-Tile Choices', icon: Layers, badgeClass: 'tag-choice' },
  { id: 'matching', label: 'Matching Pairs (Column A ➔ B)', icon: Link2, badgeClass: 'tag-matching' },
  { id: 'identification', label: 'Identification (Direct Term)', icon: FileText, badgeClass: 'tag-input' },
  { id: 'sequence_order', label: 'Sequence Reordering', icon: ListOrdered, badgeClass: 'tag-sequence' },
  { id: 'diagram_analysis', label: 'Diagram Hotspot Analysis', icon: Eye, badgeClass: 'tag-diagram' }
];

const DEFAULT_CUSTOM_NODES = [
  { id: 'node-1', title: 'Trainee Client', subtitle: 'HTTPS Browser', badge: 'Client', color: 'cyan', iconType: 'cpu', isTarget: false },
  { id: 'node-2', title: 'API Gateway', subtitle: 'OAuth Bearer Guard', badge: 'Perimeter', color: 'purple', iconType: 'shield', isTarget: false },
  { id: 'node-3', title: 'CP-ABE Policy Engine', subtitle: 'Decryption Hotspot', badge: 'Target Component', color: 'gold', iconType: 'lock', isTarget: true },
  { id: 'node-4', title: 'Encrypted Vault', subtitle: 'PostgreSQL Ciphertext', badge: 'Database', color: 'emerald', iconType: 'database', isTarget: false }
];

export default function QuizStudio() {
  const [quizDb, setQuizDb] = useState(() => getActiveQuizDatabase());
  const [selectedQuizId, setSelectedQuizId] = useState('act-1');
  const [viewMode, setViewMode] = useState('overview'); // 'overview' | 'question_editor'
  const [showNewQuizModal, setShowNewQuizModal] = useState(false);
  const [showEditQuizModal, setShowEditQuizModal] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  // Question editing / creation state
  const [editingQuestionId, setEditingQuestionId] = useState(null);
  const [editingQuestionNum, setEditingQuestionNum] = useState(null);
  const [qType, setQType] = useState('multiple_choice');
  const [qPrompt, setQPrompt] = useState('');
  const [qExplanation, setQExplanation] = useState('');
  
  // For multiple_choice & diagram_analysis
  const [mcOptions, setMcOptions] = useState(['', '', '', '']);
  const [mcCorrectIdx, setMcCorrectIdx] = useState(0);
  const [diagramType, setDiagramType] = useState('security_pipeline');

  // Image attachment state (for multiple choice and diagram questions)
  const [qImageUrl, setQImageUrl] = useState('');
  const [qImageCaption, setQImageCaption] = useState('');
  const [imageInputMode, setImageInputMode] = useState('upload'); // 'upload' | 'url'

  // Custom diagram builder state
  const [qDiagramSource, setQDiagramSource] = useState('template'); // 'template' | 'custom_flow' | 'image'
  const [qCustomTitle, setQCustomTitle] = useState('Custom Architecture Flow');
  const [qCustomNodes, setQCustomNodes] = useState(DEFAULT_CUSTOM_NODES);

  // For identification
  const [identAnswers, setIdentAnswers] = useState('');
  const [identPlaceholder, setIdentPlaceholder] = useState('');

  // For sequence_order
  const [seqSteps, setSeqSteps] = useState(['', '', '', '']);

  // For matching
  const [matchingPairs, setMatchingPairs] = useState([
    { left: '', right: '' },
    { left: '', right: '' },
    { left: '', right: '' },
    { left: '', right: '' }
  ]);

  // Quiz editing state
  const [quizMetaForm, setQuizMetaForm] = useState({
    title: '',
    category: '',
    timePerQuestion: 45,
    passingScore: 80,
    description: '',
    headerColor: '#772ce8',
    showCorrectAnswers: true
  });

  // New Quiz state
  const [newQuizTitle, setNewQuizTitle] = useState('');
  const [newQuizCategory, setNewQuizCategory] = useState('Enterprise Security');
  const [newQuizDesc, setNewQuizDesc] = useState('');
  const [newQuizTime, setNewQuizTime] = useState(45);
  const [newQuizPassing, setNewQuizPassing] = useState(80);
  const [newQuizColor, setNewQuizColor] = useState('#772ce8');
  const [newQuizShowCorrectAnswers, setNewQuizShowCorrectAnswers] = useState(true);

  const selectedQuiz = quizDb[selectedQuizId] || Object.values(quizDb)[0];

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleSelectQuiz = (quizId) => {
    setSelectedQuizId(quizId);
  };

  const handleImageFileUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("Image size should be under 5MB for smooth browser storage.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      setQImageUrl(ev.target.result);
    };
    reader.readAsDataURL(file);
  };

  // Open Question Modal for Creating
  const handleOpenAddModal = () => {
    setEditingQuestionId(null);
    setEditingQuestionNum(null);
    setQType('multiple_choice');
    setQPrompt('');
    setQExplanation('');
    setMcOptions(['', '', '', '']);
    setMcCorrectIdx(0);
    setDiagramType('security_pipeline');
    setQImageUrl('');
    setQImageCaption('');
    setImageInputMode('upload');
    setQDiagramSource('template');
    setQCustomTitle('Zero-Trust Cryptographic Pipeline Architecture');
    setQCustomNodes(JSON.parse(JSON.stringify(DEFAULT_CUSTOM_NODES)));
    setIdentAnswers('');
    setIdentPlaceholder('Type your answer here...');
    setSeqSteps(['', '', '', '']);
    setMatchingPairs([
      { left: '', right: '' },
      { left: '', right: '' },
      { left: '', right: '' },
      { left: '', right: '' }
    ]);
    setViewMode('question_editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Open Question Modal for Editing
  const handleOpenEditModal = (q, idx) => {
    setEditingQuestionId(q.id);
    setEditingQuestionNum(idx + 1);
    setQType(q.type || 'multiple_choice');
    setQPrompt(q.question || '');
    setQExplanation(q.explanation || '');

    // Restore Image
    const img = q.imageUrl || q.diagramImage || '';
    setQImageUrl(img);
    setQImageCaption(q.imageCaption || '');
    setImageInputMode(img.startsWith('data:') ? 'upload' : 'url');

    // Restore Diagram settings
    setQDiagramSource(q.diagramSource || (img ? 'image' : (Array.isArray(q.customNodes) && q.customNodes.length > 0) ? 'custom_flow' : 'template'));
    setQCustomTitle(q.customTitle || 'Custom Architectural Sequence');
    if (Array.isArray(q.customNodes) && q.customNodes.length > 0) {
      setQCustomNodes(JSON.parse(JSON.stringify(q.customNodes)));
    } else {
      setQCustomNodes(JSON.parse(JSON.stringify(DEFAULT_CUSTOM_NODES)));
    }

    if (q.type === 'multiple_choice' || q.type === 'diagram_analysis') {
      const opts = Array.isArray(q.options) ? [...q.options] : ['', '', '', ''];
      while (opts.length < 4) opts.push('');
      setMcOptions(opts);
      setMcCorrectIdx(typeof q.correctAnswer === 'number' ? q.correctAnswer : 0);
      setDiagramType(q.diagramType || 'security_pipeline');
    } else if (q.type === 'identification') {
      setIdentAnswers(Array.isArray(q.acceptedAnswers) ? q.acceptedAnswers.join(', ') : '');
      setIdentPlaceholder(q.placeholder || 'Type your answer here...');
    } else if (q.type === 'sequence_order') {
      const steps = Array.isArray(q.correctOrder) ? [...q.correctOrder] : ['', '', '', ''];
      while (steps.length < 3) steps.push('');
      setSeqSteps(steps);
    } else if (q.type === 'matching') {
      const pairs = Array.isArray(q.pairs) 
        ? q.pairs.map(p => ({
            left: p.left.replace(/^\d+\.\s*/, ''),
            right: p.right.replace(/^[A-Z]\.\s*/, '')
          }))
        : [{ left: '', right: '' }, { left: '', right: '' }];
      setMatchingPairs(pairs);
    }

    setViewMode('question_editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Open Quiz Metadata Edit Modal
  const handleOpenEditQuizModal = () => {
    if (!selectedQuiz) return;
    setQuizMetaForm({
      title: selectedQuiz.title || '',
      category: selectedQuiz.category || '',
      timePerQuestion: selectedQuiz.timePerQuestion || 45,
      passingScore: selectedQuiz.passingScore || 80,
      description: selectedQuiz.description || '',
      headerColor: selectedQuiz.headerColor || '#772ce8',
      showCorrectAnswers: selectedQuiz.showCorrectAnswers !== false
    });
    setShowEditQuizModal(true);
  };

  // Save Quiz Metadata
  const handleSaveQuizMetadata = (e) => {
    e.preventDefault();
    if (!quizMetaForm.title.trim()) {
      alert("Please provide a quiz title.");
      return;
    }

    updateQuizMetadataStorage(selectedQuizId, {
      title: quizMetaForm.title.trim(),
      category: quizMetaForm.category.trim(),
      timePerQuestion: parseInt(quizMetaForm.timePerQuestion) || 45,
      passingScore: parseInt(quizMetaForm.passingScore) || 80,
      description: quizMetaForm.description.trim(),
      headerColor: quizMetaForm.headerColor,
      showCorrectAnswers: quizMetaForm.showCorrectAnswers !== false
    });

    setQuizDb(getActiveQuizDatabase());
    setShowEditQuizModal(false);
    showToast(`Updated assessment settings for "${quizMetaForm.title}"!`);
  };

  // Delete question
  const handleDeleteQuestion = (questionId) => {
    if (window.confirm("Are you sure you want to remove this question from the assessment pool?")) {
      const updatedQuiz = deleteQuestionFromQuizStorage(selectedQuizId, questionId);
      if (updatedQuiz) {
        setQuizDb(getActiveQuizDatabase());
        showToast("Question removed from assessment pool.");
      }
    }
  };

  // Reset all to defaults
  const handleResetDefaults = () => {
    if (window.confirm("Reset all course quizzes and questions back to the default certified curriculum? Custom authored questions will be removed.")) {
      const defaults = resetQuizDatabaseToDefaults();
      setQuizDb(defaults);
      showToast("Quiz database restored to verified default syllabus.");
    }
  };

  // Submit Question (Create or Edit)
  const handleSaveQuestionSubmit = (e) => {
    e.preventDefault();
    if (!qPrompt.trim()) {
      alert("Please provide the question prompt.");
      return;
    }

    let questionObj = {
      id: editingQuestionId || `q-${Date.now().toString(36)}`,
      type: qType,
      question: qPrompt.trim(),
      explanation: qExplanation.trim() || 'Verified by Lead Course Instructor.'
    };

    if (qType === 'multiple_choice') {
      const filtered = mcOptions.map(o => o.trim()).filter(Boolean);
      if (filtered.length < 2) {
        alert("Please provide at least 2 choice options.");
        return;
      }
      questionObj.options = filtered;
      questionObj.correctAnswer = Math.min(mcCorrectIdx, filtered.length - 1);
      if (qImageUrl.trim()) {
        questionObj.imageUrl = qImageUrl.trim();
        if (qImageCaption.trim()) questionObj.imageCaption = qImageCaption.trim();
      }
    } else if (qType === 'diagram_analysis') {
      const filtered = mcOptions.map(o => o.trim()).filter(Boolean);
      if (filtered.length < 2) {
        alert("Please provide at least 2 choice options.");
        return;
      }
      questionObj.options = filtered;
      questionObj.correctAnswer = Math.min(mcCorrectIdx, filtered.length - 1);
      questionObj.diagramSource = qDiagramSource;

      if (qDiagramSource === 'image') {
        if (!qImageUrl.trim()) {
          alert("Please upload or provide an image URL for the diagram analysis.");
          return;
        }
        questionObj.imageUrl = qImageUrl.trim();
        if (qImageCaption.trim()) questionObj.imageCaption = qImageCaption.trim();
        if (qCustomTitle.trim()) questionObj.customTitle = qCustomTitle.trim();
      } else if (qDiagramSource === 'custom_flow') {
        questionObj.customTitle = qCustomTitle.trim() || 'Custom Architectural Sequence';
        questionObj.customNodes = qCustomNodes;
      } else {
        questionObj.diagramType = diagramType;
      }
    } else if (qType === 'identification') {
      const answersList = identAnswers
        .split(',')
        .map(a => a.trim().toLowerCase())
        .filter(Boolean);

      if (answersList.length === 0) {
        alert("Please enter at least one accepted answer.");
        return;
      }
      questionObj.acceptedAnswers = answersList;
      questionObj.placeholder = identPlaceholder.trim() || 'Type your answer here...';
    } else if (qType === 'sequence_order') {
      const filteredSteps = seqSteps.map(s => s.trim()).filter(Boolean);
      if (filteredSteps.length < 2) {
        alert("Please enter at least 2 chronological sequence steps.");
        return;
      }
      questionObj.correctOrder = filteredSteps;
      questionObj.initialOrder = [...filteredSteps].sort(() => 0.5 - Math.random());
    } else if (qType === 'matching') {
      const validPairs = matchingPairs
        .filter(p => p.left.trim() && p.right.trim())
        .map((p, pIdx) => ({
          id: `m-cust-${pIdx}-${Date.now().toString(36)}`,
          left: p.left.trim(),
          right: p.right.trim()
        }));

      if (validPairs.length < 2) {
        alert("Please provide at least 2 complete pairs for Column A and Column B.");
        return;
      }
      questionObj.pairs = validPairs;
    }

    if (editingQuestionId) {
      updateQuestionInQuizStorage(selectedQuizId, editingQuestionId, questionObj);
      showToast(`Updated Question #${editingQuestionNum} successfully!`);
    } else {
      addQuestionToQuizStorage(selectedQuizId, questionObj);
      showToast(`Added new ${qType} question to ${selectedQuiz.title}!`);
    }

    setQuizDb(getActiveQuizDatabase());
    setViewMode('overview');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Create New Quiz Submit
  const handleCreateNewQuiz = (e) => {
    e.preventDefault();
    if (!newQuizTitle.trim()) {
      alert("Please enter a quiz title.");
      return;
    }

    const newId = `quiz-${Date.now().toString(36)}`;
    const newQuizObj = {
      id: newId,
      title: newQuizTitle.trim(),
      instructor: 'Lead Trainer David Lim',
      category: newQuizCategory.trim(),
      headerColor: newQuizColor,
      timePerQuestion: parseInt(newQuizTime) || 45,
      passingScore: parseInt(newQuizPassing) || 80,
      showCorrectAnswers: newQuizShowCorrectAnswers !== false,
      badgeAwarded: 'crypto_knight',
      description: newQuizDesc.trim() || 'Custom enterprise training module published by Lead Course Instructor.',
      learningObjectives: [
        'Master essential zero-trust compliance standards',
        'Verify enterprise cryptographic isolation policies',
        'Evaluate access anomaly detection indicators'
      ],
      questions: []
    };

    saveQuizToStorage(newQuizObj);
    setQuizDb(getActiveQuizDatabase());
    setSelectedQuizId(newId);
    setShowNewQuizModal(false);
    showToast(`Created new assessment: "${newQuizObj.title}"`);
    
    setNewQuizTitle('');
    setNewQuizDesc('');
  };

  // =========================================================================
  // DEDICATED FULL-PAGE QUESTION AUTHORING & EDITING WORKBENCH
  // Replaces the cramped popup modal with a spacious, professional editor
  // =========================================================================
  if (viewMode === 'question_editor') {
    const isEditing = !!editingQuestionId;
    const currentTypeConfig = QUESTION_TYPES.find(t => t.id === qType) || QUESTION_TYPES[0];
    const TypeIcon = currentTypeConfig.icon;
    const nextQuestionNum = (selectedQuiz?.questions ? selectedQuiz.questions.length : 0) + 1;
    const displayQuestionNum = editingQuestionNum || nextQuestionNum;

    return (
      <div className="quiz-studio-layout question-editor-page animate-fadeIn">
        {toastMessage && (
          <div className="card notice-box mb-16 flex-between animate-fadeIn">
            <div className="flex-align gap-8">
              <CheckCircle2 size={16} className="text-emerald" />
              <span className="font-semibold text-sm">{toastMessage}</span>
            </div>
          </div>
        )}

        {/* TOP BREADCRUMB & CONTROL BANNER */}
        <div className="card editor-top-banner mb-24">
          <div className="flex-between flex-wrap gap-16">
            <div>
              <div className="editor-breadcrumbs flex-align gap-8 text-xs text-secondary mb-8">
                <button
                  type="button"
                  className="breadcrumb-nav-btn"
                  onClick={() => setViewMode('overview')}
                >
                  <ArrowLeft size={13} />
                  <span>Course Assessments</span>
                </button>
                <span className="text-secondary">/</span>
                <span className="font-semibold text-slate-700">{selectedQuiz?.title}</span>
                <span className="text-secondary">/</span>
                <span className="text-purple font-bold">
                  {isEditing ? `Edit Question #${displayQuestionNum}` : `Author Question #${displayQuestionNum}`}
                </span>
              </div>

              <div className="flex-align gap-12 flex-wrap">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm flex-align gap-6"
                  onClick={() => setViewMode('overview')}
                  title="Return to assessment overview without saving"
                >
                  <ArrowLeft size={15} />
                  <span>Back to Assessment</span>
                </button>
                <h2 className="editor-page-heading m-0">
                  {isEditing 
                    ? `Editing Question #${displayQuestionNum}` 
                    : `Authoring Question #${displayQuestionNum}`}
                </h2>
                <span className={`badge ${currentTypeConfig.badgeClass} font-bold`}>
                  <TypeIcon size={13} />
                  <span>{currentTypeConfig.label}</span>
                </span>
              </div>
              <p className="text-secondary text-xs mt-6 mb-0">
                Course: <strong>{selectedQuiz?.title}</strong> ({selectedQuiz?.category}) · Supervised by {selectedQuiz?.instructor}
              </p>
            </div>

            <div className="flex-align gap-10">
              <button
                type="button"
                className="btn btn-secondary btn-md"
                onClick={() => setViewMode('overview')}
              >
                Cancel & Return
              </button>
              <button
                type="button"
                className="btn btn-primary btn-md flex-align gap-6"
                onClick={handleSaveQuestionSubmit}
              >
                <Save size={16} />
                <span>{isEditing ? 'Save Question Changes' : 'Save Question to Assessment'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* 2-COLUMN SPACIOUS WORKBENCH */}
        <div className="editor-workbench-layout">
          {/* LEFT COLUMN: MAIN CONFIGURATION FORM */}
          <form onSubmit={handleSaveQuestionSubmit} className="editor-main-form-col">
            {/* STEP 1: QUESTION MECHANISM */}
            <div className="card editor-section-card mb-20">
              <div className="editor-section-header mb-16">
                <span className="step-badge">Step 1</span>
                <div>
                  <h3 className="editor-section-title">Select Interaction Mechanism</h3>
                  <p className="text-secondary text-xs">
                    Choose how trainees will analyze and interact with this examination item.
                  </p>
                </div>
              </div>

              <div className="grid-3-col gap-12">
                {QUESTION_TYPES.map(t => {
                  const isTypeSelected = qType === t.id;
                  const Icon = t.icon;

                  return (
                    <button
                      key={t.id}
                      type="button"
                      className={`qtype-card-select ${isTypeSelected ? 'qtype-card-active' : ''}`}
                      onClick={() => setQType(t.id)}
                    >
                      <div className="flex-between mb-8">
                        <div className={`qtype-icon-box ${isTypeSelected ? 'icon-box-active' : ''}`}>
                          <Icon size={20} />
                        </div>
                        {isTypeSelected && <Check size={16} className="text-purple font-bold" />}
                      </div>
                      <h4 className="qtype-card-heading">{t.label}</h4>
                      <p className="qtype-card-sub">
                        {t.id === 'multiple_choice' && 'Fast-paced Kahoot 4-tile multiple choice selection with attached image option.'}
                        {t.id === 'matching' && 'Pairwise matching between Column A terms and Column B definitions.'}
                        {t.id === 'identification' && 'Direct term entry with flexible synonym acceptance matching.'}
                        {t.id === 'sequence_order' && 'Interactive step reordering into chronological or logical order.'}
                        {t.id === 'diagram_analysis' && 'Architecture hotspot evaluation with custom pipeline builder or image.'}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* STEP 2: PROMPT & SCENARIO */}
            <div className="card editor-section-card mb-20">
              <div className="editor-section-header mb-16">
                <span className="step-badge">Step 2</span>
                <div>
                  <h3 className="editor-section-title">Question Prompt & Operational Scenario</h3>
                  <p className="text-secondary text-xs">
                    Formulate the challenge, problem statement, or scenario presented to the trainee.
                  </p>
                </div>
              </div>

              <textarea
                className="clean-input w-full editor-prompt-textarea"
                rows={3}
                required
                placeholder="e.g. Which cryptographic component is responsible for evaluating the user's attribute credentials against the ciphertext policy tree in a Zero-Trust architecture?"
                value={qPrompt}
                onChange={(e) => setQPrompt(e.target.value)}
              />
            </div>

            {/* STEP 3: MECHANISM CONFIGURATION */}
            <div className="card editor-section-card mb-20">
              <div className="editor-section-header mb-16">
                <span className="step-badge">Step 3</span>
                <div>
                  <h3 className="editor-section-title">Configure Options, Solutions & Media</h3>
                  <p className="text-secondary text-xs">
                    Define the correct solution, choices, sequence steps, matching pairs, or diagram architecture.
                  </p>
                </div>
              </div>

              {/* CASE A: MATCHING QUESTION BUILDER */}
              {qType === 'matching' && (
                <div className="p-16 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex-between mb-12">
                    <label className="font-bold text-xs uppercase tracking-wider text-purple flex-align gap-6">
                      <Link2 size={15} />
                      <span>Configure Column A and Column B Pairs</span>
                    </label>
                    <button
                      type="button"
                      className="btn btn-secondary btn-xs flex-align gap-4"
                      onClick={() => setMatchingPairs([...matchingPairs, { left: '', right: '' }])}
                      disabled={matchingPairs.length >= 6}
                    >
                      <Plus size={13} /> Add Pair
                    </button>
                  </div>
                  <p className="text-xs text-secondary mb-14">
                    Enter the term/component on the left (Column A), and its matching definition/function on the right (Column B). Items are dynamically randomized when presented to trainees.
                  </p>

                  <div className="matching-builder-stack space-y-3">
                    {matchingPairs.map((pair, pIdx) => (
                      <div key={pIdx} className="matching-pair-input-row flex-align gap-10 p-10 bg-white rounded-lg border border-slate-200">
                        <span className="badge badge-purple flex-shrink-0 font-bold">{pIdx + 1}</span>
                        <input
                          type="text"
                          className="clean-input flex-1"
                          placeholder={`Column A #${pIdx + 1} (e.g. CP-ABE Ciphertext Encryption)`}
                          value={pair.left}
                          onChange={(e) => {
                            const updated = [...matchingPairs];
                            updated[pIdx].left = e.target.value;
                            setMatchingPairs(updated);
                          }}
                          required
                        />
                        <span className="text-secondary font-bold text-base">➔</span>
                        <input
                          type="text"
                          className="clean-input flex-1"
                          placeholder={`Column B [${String.fromCharCode(65 + pIdx)}] (e.g. Cryptographic policy tree bound to payload)`}
                          value={pair.right}
                          onChange={(e) => {
                            const updated = [...matchingPairs];
                            updated[pIdx].right = e.target.value;
                            setMatchingPairs(updated);
                          }}
                          required
                        />
                        {matchingPairs.length > 2 && (
                          <button
                            type="button"
                            className="btn-icon-danger flex-shrink-0"
                            onClick={() => {
                              const updated = matchingPairs.filter((_, idx) => idx !== pIdx);
                              setMatchingPairs(updated);
                            }}
                            title="Remove pair"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* CASE B: MULTIPLE CHOICE 4-TILE BUILDER & ATTACHED IMAGE */}
              {qType === 'multiple_choice' && (
                <div className="p-16 bg-slate-50 rounded-xl border border-slate-200">
                  <label className="font-bold text-xs uppercase tracking-wider text-blue mb-12 block">
                    Choice Options (Select Radio Button for Correct Answer)
                  </label>

                  <div className="grid-2-col gap-12 mb-20">
                    {mcOptions.map((opt, oIdx) => {
                      const colors = [
                        { label: 'Red ▲', color: '#e21b3c' },
                        { label: 'Blue ◆', color: '#1368ce' },
                        { label: 'Yellow ●', color: '#d89e00' },
                        { label: 'Green ■', color: '#26890c' }
                      ];

                      return (
                        <div key={oIdx} className="choice-option-input-box p-10 bg-white rounded-lg border flex-align gap-10">
                          <input
                            type="radio"
                            name="mc_correct_choice"
                            checked={mcCorrectIdx === oIdx}
                            onChange={() => setMcCorrectIdx(oIdx)}
                            className="radio-accent"
                            title="Mark as correct answer"
                          />
                          <span className="font-bold text-xs flex-shrink-0" style={{ color: colors[oIdx].color }}>
                            {colors[oIdx].label}:
                          </span>
                          <input
                            type="text"
                            className="clean-input flex-1"
                            placeholder={`Option ${oIdx + 1}...`}
                            value={opt}
                            onChange={(e) => {
                              const updated = [...mcOptions];
                              updated[oIdx] = e.target.value;
                              setMcOptions(updated);
                            }}
                            required
                          />
                        </div>
                      );
                    })}
                  </div>

                  {/* OPTIONAL ATTACHED REFERENCE IMAGE */}
                  <div className="border-top pt-16">
                    <div className="flex-between mb-8">
                      <label className="font-bold text-xs uppercase tracking-wider text-purple flex-align gap-6">
                        <ImageIcon size={15} />
                        <span>Attached Reference Graphic / Image (Optional)</span>
                      </label>
                      {qImageUrl && (
                        <button
                          type="button"
                          className="btn-icon-danger text-xs flex-align gap-4"
                          onClick={() => {
                            setQImageUrl('');
                            setQImageCaption('');
                          }}
                          title="Remove attached image"
                        >
                          <X size={13} />
                          <span>Remove Image</span>
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-secondary mb-12">
                      Attach an architectural diagram, screenshot, or code graphic to accompany this multiple choice question.
                    </p>

                    {!qImageUrl ? (
                      <div className="image-authoring-input-zone bg-white p-14 rounded-lg border border-slate-200">
                        <div className="flex-align gap-10 mb-10">
                          <button
                            type="button"
                            className={`btn btn-xs ${imageInputMode === 'upload' ? 'btn-primary' : 'btn-secondary'}`}
                            onClick={() => setImageInputMode('upload')}
                          >
                            <Upload size={12} /> Upload File (PNG/JPG/SVG)
                          </button>
                          <button
                            type="button"
                            className={`btn btn-xs ${imageInputMode === 'url' ? 'btn-primary' : 'btn-secondary'}`}
                            onClick={() => setImageInputMode('url')}
                          >
                            <Link2 size={12} /> Enter Image URL
                          </button>
                        </div>

                        {imageInputMode === 'upload' ? (
                          <div className="upload-dropzone">
                            <input
                              type="file"
                              accept="image/*"
                              id="mc-image-file-input"
                              className="hidden-file-input"
                              onChange={handleImageFileUpload}
                            />
                            <label htmlFor="mc-image-file-input" className="file-upload-label flex-column align-center justify-center p-20 cursor-pointer">
                              <FileUp size={28} className="text-purple mb-6" />
                              <span className="font-bold text-xs text-slate-800">Select an image file from your computer</span>
                              <span className="text-2xs text-secondary mt-2">Supports PNG, JPG, WebP, SVG up to 5MB (Saved directly in browser)</span>
                            </label>
                          </div>
                        ) : (
                          <div className="url-input-group">
                            <input
                              type="url"
                              className="clean-input w-full text-xs"
                              placeholder="https://example.com/diagram.png or data:image/..."
                              value={qImageUrl}
                              onChange={(e) => setQImageUrl(e.target.value)}
                            />
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="image-preview-card p-12 bg-white rounded-lg border border-slate-200 flex-align gap-16">
                        <img src={qImageUrl} alt="Preview" className="builder-thumbnail-img" />
                        <div className="flex-1">
                          <label className="field-label text-xs font-bold text-secondary mb-4 block">
                            Image Caption / Reference Title
                          </label>
                          <input
                            type="text"
                            className="clean-input w-full text-xs"
                            placeholder="e.g. Figure 1: Network Traffic Inspection Topology"
                            value={qImageCaption}
                            onChange={(e) => setQImageCaption(e.target.value)}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* CASE C: DIAGRAM HOTSPOT ANALYSIS BUILDER */}
              {qType === 'diagram_analysis' && (
                <div className="p-16 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex-between mb-10">
                    <label className="font-bold text-xs uppercase tracking-wider text-purple flex-align gap-6">
                      <Layers size={15} />
                      <span>Diagram Architecture Source</span>
                    </label>
                  </div>

                  {/* DIAGRAM SOURCE SELECTOR TABS */}
                  <div className="diagram-source-selector grid-3-col gap-10 mb-16">
                    <button
                      type="button"
                      className={`btn btn-sm ${qDiagramSource === 'template' ? 'btn-primary' : 'btn-secondary'} flex-align justify-center gap-6`}
                      onClick={() => setQDiagramSource('template')}
                    >
                      <Layers size={14} />
                      <span>Built-in Templates</span>
                    </button>
                    <button
                      type="button"
                      className={`btn btn-sm ${qDiagramSource === 'custom_flow' ? 'btn-primary' : 'btn-secondary'} flex-align justify-center gap-6`}
                      onClick={() => setQDiagramSource('custom_flow')}
                    >
                      <Sparkles size={14} />
                      <span>Custom Sequence Flow</span>
                    </button>
                    <button
                      type="button"
                      className={`btn btn-sm ${qDiagramSource === 'image' ? 'btn-primary' : 'btn-secondary'} flex-align justify-center gap-6`}
                      onClick={() => setQDiagramSource('image')}
                    >
                      <Upload size={14} />
                      <span>Upload Diagram Image</span>
                    </button>
                  </div>

                  {/* SUB-SOURCE 1: BUILT-IN TEMPLATES */}
                  {qDiagramSource === 'template' && (
                    <div className="mb-16 p-14 bg-white rounded-lg border border-slate-200">
                      <label className="field-label text-xs font-bold text-secondary mb-4 block">
                        Select Standard Architecture Diagram
                      </label>
                      <select 
                        className="clean-input w-full"
                        value={diagramType}
                        onChange={(e) => setDiagramType(e.target.value)}
                      >
                        <option value="security_pipeline">Zero-Trust Pipeline (Network ➔ CP-ABE ➔ Database)</option>
                        <option value="clearance_hierarchy">Clearance Level Pyramid (Root Admin ➔ Account Mgr ➔ Staff)</option>
                        <option value="data_flow">Data Privacy Relationship Flow (Subject ➔ PIC ➔ PIP)</option>
                        <option value="tenant_partition">Multi-Tenant Cryptographic Partition (Tenant Alpha / Beta Wall)</option>
                      </select>
                    </div>
                  )}

                  {/* SUB-SOURCE 2: CUSTOM SEQUENCE FLOW BUILDER */}
                  {qDiagramSource === 'custom_flow' && (
                    <div className="mb-16 p-14 bg-white rounded-lg border border-slate-200">
                      <div className="mb-12">
                        <label className="field-label text-xs font-bold text-secondary mb-4 block">
                          Custom Diagram Title / Header Strip
                        </label>
                        <input
                          type="text"
                          className="clean-input w-full text-xs font-bold"
                          placeholder="e.g. Distributed Authentication & Access Token Pipeline"
                          value={qCustomTitle}
                          onChange={(e) => setQCustomTitle(e.target.value)}
                        />
                      </div>

                      <div className="flex-between mb-10">
                        <label className="font-bold text-xs uppercase tracking-wider text-purple">
                          Sequence Flow Nodes ({qCustomNodes.length})
                        </label>
                        <button
                          type="button"
                          className="btn btn-secondary btn-xs flex-align gap-4"
                          disabled={qCustomNodes.length >= 5}
                          onClick={() => {
                            const newId = `node-${Date.now().toString(36)}`;
                            setQCustomNodes([
                              ...qCustomNodes,
                              {
                                id: newId,
                                title: `Component ${qCustomNodes.length + 1}`,
                                subtitle: 'Process Description',
                                badge: 'Service',
                                color: 'cyan',
                                iconType: 'server',
                                isTarget: false
                              }
                            ]);
                          }}
                        >
                          <Plus size={12} /> Add Node
                        </button>
                      </div>

                      <div className="custom-flow-builder-stack space-y-3 mb-10">
                        {qCustomNodes.map((node, nIdx) => (
                          <div key={node.id || nIdx} className={`custom-node-builder-card p-12 rounded-lg border flex-between gap-10 ${node.isTarget ? 'bg-amber-50 border-amber-300' : 'bg-slate-50 border-slate-200'}`}>
                            <div className="flex-align gap-8 flex-1 flex-wrap">
                              <span className="badge badge-purple flex-shrink-0 font-bold">{nIdx + 1}</span>
                              
                              <input
                                type="text"
                                className="clean-input text-xs font-bold w-130"
                                placeholder="Component Name"
                                value={node.title}
                                onChange={(e) => {
                                  const updated = [...qCustomNodes];
                                  updated[nIdx].title = e.target.value;
                                  setQCustomNodes(updated);
                                }}
                              />

                              <input
                                type="text"
                                className="clean-input text-xs w-140"
                                placeholder="Function / Subtitle"
                                value={node.subtitle}
                                onChange={(e) => {
                                  const updated = [...qCustomNodes];
                                  updated[nIdx].subtitle = e.target.value;
                                  setQCustomNodes(updated);
                                }}
                              />

                              <input
                                type="text"
                                className="clean-input text-xs w-100"
                                placeholder="Badge Tag"
                                value={node.badge}
                                onChange={(e) => {
                                  const updated = [...qCustomNodes];
                                  updated[nIdx].badge = e.target.value;
                                  setQCustomNodes(updated);
                                }}
                              />

                              <select
                                className="clean-input text-xs"
                                value={node.color}
                                onChange={(e) => {
                                  const updated = [...qCustomNodes];
                                  updated[nIdx].color = e.target.value;
                                  setQCustomNodes(updated);
                                }}
                              >
                                <option value="purple">Purple</option>
                                <option value="cyan">Cyan</option>
                                <option value="emerald">Emerald</option>
                                <option value="gold">Gold</option>
                                <option value="rose">Rose</option>
                              </select>

                              <select
                                className="clean-input text-xs"
                                value={node.iconType}
                                onChange={(e) => {
                                  const updated = [...qCustomNodes];
                                  updated[nIdx].iconType = e.target.value;
                                  setQCustomNodes(updated);
                                }}
                              >
                                <option value="cpu">CPU / Process</option>
                                <option value="server">Server</option>
                                <option value="database">Database</option>
                                <option value="cloud">Cloud</option>
                                <option value="shield">Shield</option>
                                <option value="lock">Lock</option>
                                <option value="code">Code</option>
                              </select>
                            </div>

                            <div className="flex-align gap-8 flex-shrink-0">
                              <label className="flex-align gap-4 text-xs font-bold text-amber-700 cursor-pointer" title="Make this the highlighted/focus component">
                                <input
                                  type="radio"
                                  name="custom_target_node_radio"
                                  checked={!!node.isTarget}
                                  onChange={() => {
                                    const updated = qCustomNodes.map((nd, idx) => ({
                                      ...nd,
                                      isTarget: idx === nIdx
                                    }));
                                    setQCustomNodes(updated);
                                  }}
                                />
                                <span>Target</span>
                              </label>

                              {qCustomNodes.length > 2 && (
                                <button
                                  type="button"
                                  className="btn-icon-danger"
                                  onClick={() => {
                                    const updated = qCustomNodes.filter((_, idx) => idx !== nIdx);
                                    setQCustomNodes(updated);
                                  }}
                                  title="Delete node"
                                >
                                  <Trash2 size={13} />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* SUB-SOURCE 3: UPLOAD DIAGRAM IMAGE OR URL */}
                  {qDiagramSource === 'image' && (
                    <div className="mb-16 p-14 bg-white rounded-lg border border-slate-200">
                      <div className="flex-between mb-8">
                        <label className="field-label text-xs font-bold text-secondary">
                          Upload Diagram Graphic File or Paste Link
                        </label>
                        {qImageUrl && (
                          <button
                            type="button"
                            className="btn-icon-danger text-xs flex-align gap-4"
                            onClick={() => {
                              setQImageUrl('');
                              setQImageCaption('');
                            }}
                          >
                            <X size={12} />
                            <span>Clear Diagram</span>
                          </button>
                        )}
                      </div>

                      {!qImageUrl ? (
                        <div>
                          <div className="flex-align gap-10 mb-10">
                            <button
                              type="button"
                              className={`btn btn-xs ${imageInputMode === 'upload' ? 'btn-primary' : 'btn-secondary'}`}
                              onClick={() => setImageInputMode('upload')}
                            >
                              <Upload size={12} /> Upload File (PNG/JPG/SVG)
                            </button>
                            <button
                              type="button"
                              className={`btn btn-xs ${imageInputMode === 'url' ? 'btn-primary' : 'btn-secondary'}`}
                              onClick={() => setImageInputMode('url')}
                            >
                              <Link2 size={12} /> Enter Image URL
                            </button>
                          </div>

                          {imageInputMode === 'upload' ? (
                            <div className="upload-dropzone">
                              <input
                                type="file"
                                accept="image/*"
                                id="diagram-image-file-input"
                                className="hidden-file-input"
                                onChange={handleImageFileUpload}
                              />
                              <label htmlFor="diagram-image-file-input" className="file-upload-label flex-column align-center justify-center p-24 cursor-pointer">
                                <FileUp size={32} className="text-purple mb-6" />
                                <span className="font-bold text-xs text-slate-800">Select diagram file from computer</span>
                                <span className="text-2xs text-secondary mt-2">Any architectural diagram (PNG, JPG, WebP, SVG) up to 5MB</span>
                              </label>
                            </div>
                          ) : (
                            <input
                              type="url"
                              className="clean-input w-full text-xs"
                              placeholder="https://example.com/network-diagram.png"
                              value={qImageUrl}
                              onChange={(e) => setQImageUrl(e.target.value)}
                            />
                          )}
                        </div>
                      ) : (
                        <div className="image-preview-card p-12 bg-slate-50 rounded-lg border flex-align gap-16">
                          <img src={qImageUrl} alt="Diagram Preview" className="builder-thumbnail-img" />
                          <div className="flex-1">
                            <label className="field-label text-xs font-bold text-secondary mb-2 block">
                              Diagram Caption / Assessment Prompt Header
                            </label>
                            <input
                              type="text"
                              className="clean-input w-full text-xs"
                              placeholder="e.g. Figure 3: Enterprise Zero-Trust Data Flow"
                              value={qImageCaption}
                              onChange={(e) => setQImageCaption(e.target.value)}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* 4-CHOICE OPTIONS FOR DIAGRAM QUESTION */}
                  <label className="font-bold text-xs uppercase tracking-wider text-blue mb-10 block">
                    Analysis Choice Options (Select Radio Button for Correct Answer)
                  </label>

                  <div className="grid-2-col gap-12">
                    {mcOptions.map((opt, oIdx) => {
                      const colors = [
                        { label: 'Red ▲', color: '#e21b3c' },
                        { label: 'Blue ◆', color: '#1368ce' },
                        { label: 'Yellow ●', color: '#d89e00' },
                        { label: 'Green ■', color: '#26890c' }
                      ];

                      return (
                        <div key={oIdx} className="choice-option-input-box p-10 bg-white rounded-lg border flex-align gap-10">
                          <input
                            type="radio"
                            name="mc_correct_choice"
                            checked={mcCorrectIdx === oIdx}
                            onChange={() => setMcCorrectIdx(oIdx)}
                            className="radio-accent"
                            title="Mark as correct answer"
                          />
                          <span className="font-bold text-xs flex-shrink-0" style={{ color: colors[oIdx].color }}>
                            {colors[oIdx].label}:
                          </span>
                          <input
                            type="text"
                            className="clean-input flex-1"
                            placeholder={`Option ${oIdx + 1}...`}
                            value={opt}
                            onChange={(e) => {
                              const updated = [...mcOptions];
                              updated[oIdx] = e.target.value;
                              setMcOptions(updated);
                            }}
                            required
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* CASE D: IDENTIFICATION BUILDER */}
              {qType === 'identification' && (
                <div className="p-16 bg-slate-50 rounded-xl border border-slate-200">
                  <label className="font-bold text-xs uppercase tracking-wider text-purple mb-10 block">
                    Accepted Answers & Input Hint
                  </label>
                  <div className="mb-10">
                    <label className="field-label text-xs mb-2 block font-semibold text-slate-700">
                      Accepted Answers (Comma-separated variations)
                    </label>
                    <input
                      type="text"
                      className="clean-input w-full"
                      placeholder="e.g. zero trust, zta, zero-trust architecture"
                      value={identAnswers}
                      onChange={(e) => setIdentAnswers(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label className="field-label text-xs mb-2 block font-semibold text-slate-700">
                      Input Field Placeholder / Hint
                    </label>
                    <input
                      type="text"
                      className="clean-input w-full"
                      placeholder="e.g. Type the security model name..."
                      value={identPlaceholder}
                      onChange={(e) => setIdentPlaceholder(e.target.value)}
                    />
                  </div>
                </div>
              )}

              {/* CASE E: SEQUENCE ORDERING BUILDER */}
              {qType === 'sequence_order' && (
                <div className="p-16 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex-between mb-10">
                    <label className="font-bold text-xs uppercase tracking-wider text-green flex-align gap-6">
                      <ListOrdered size={15} />
                      <span>Enter Steps in Correct Chronological Order</span>
                    </label>
                    <button
                      type="button"
                      className="btn btn-secondary btn-xs flex-align gap-4"
                      onClick={() => setSeqSteps([...seqSteps, ''])}
                      disabled={seqSteps.length >= 6}
                    >
                      <Plus size={12} /> Add Step
                    </button>
                  </div>
                  <p className="text-xs text-secondary mb-12">
                    Define the steps in solved order. The system will automatically scramble them when presenting to trainees.
                  </p>
                  <div className="seq-builder-stack space-y-3">
                    {seqSteps.map((step, sIdx) => (
                      <div key={sIdx} className="seq-step-input-row flex-align gap-10 p-8 bg-white rounded-lg border border-slate-200">
                        <span className="step-num-pill">{sIdx + 1}</span>
                        <input
                          type="text"
                          className="clean-input flex-1"
                          placeholder={`Step #${sIdx + 1} description...`}
                          value={step}
                          onChange={(e) => {
                            const updated = [...seqSteps];
                            updated[sIdx] = e.target.value;
                            setSeqSteps(updated);
                          }}
                          required
                        />
                        {seqSteps.length > 2 && (
                          <button
                            type="button"
                            className="btn-icon-danger flex-shrink-0"
                            onClick={() => {
                              const updated = seqSteps.filter((_, idx) => idx !== sIdx);
                              setSeqSteps(updated);
                            }}
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* STEP 4: EXPLANATION & ANALYSIS */}
            <div className="card editor-section-card mb-20">
              <div className="editor-section-header mb-16">
                <span className="step-badge">Step 4</span>
                <div>
                  <h3 className="editor-section-title">Instructional Solution Explanation & Technical Analysis</h3>
                  <p className="text-secondary text-xs">
                    Displayed immediately after trainees answer to reinforce zero-trust theory and statutory standards.
                  </p>
                </div>
              </div>

              <textarea
                className="clean-input w-full text-sm"
                rows={3}
                placeholder="Explain why this answer is correct, citing CP-ABE policy attributes, zero-trust principles, or DPA compliance..."
                value={qExplanation}
                onChange={(e) => setQExplanation(e.target.value)}
              />
            </div>

            {/* BOTTOM ACTIONS BAR */}
            <div className="editor-bottom-bar card p-18 flex-between">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setViewMode('overview')}
              >
                Cancel & Return
              </button>
              <button
                type="submit"
                className="btn btn-primary btn-md flex-align gap-6"
              >
                <Save size={16} />
                <span>{isEditing ? 'Save Question Changes' : 'Save Question to Assessment Pool'}</span>
              </button>
            </div>
          </form>

          {/* RIGHT COLUMN: REAL-TIME TRAINEE PREVIEW & CONTEXT INSPECTOR */}
          <div className="editor-sidebar-col">
            <div className="editor-sticky-panel">
              {/* LIVE TRAINEE PREVIEW CARD */}
              <div className="card preview-card p-18 mb-16">
                <div className="flex-between mb-12 pb-10 border-bottom">
                  <div className="flex-align gap-6 text-xs font-bold text-secondary uppercase tracking-wider">
                    <Eye size={14} className="text-purple" />
                    <span>Live Trainee Viewport Preview</span>
                  </div>
                  <span className={`badge ${currentTypeConfig.badgeClass} font-bold text-2xs`}>
                    {currentTypeConfig.label}
                  </span>
                </div>

                <div className="preview-question-meta mb-10 flex-align gap-6">
                  <span className="question-seq-num">Q#{displayQuestionNum}</span>
                </div>

                <div className="preview-prompt-text font-bold text-sm text-slate-900 mb-12">
                  {qPrompt || 'Your question prompt will appear here as you type...'}
                </div>

                {/* Multiple choice reference image preview */}
                {qType === 'multiple_choice' && qImageUrl && (
                  <div className="preview-attached-image mb-12">
                    <img src={qImageUrl} alt="Reference Preview" className="w-full rounded border max-h-180 object-contain bg-slate-50" />
                    {qImageCaption && <div className="text-2xs text-secondary mt-2 text-center italic">{qImageCaption}</div>}
                  </div>
                )}

                {/* Diagram render preview */}
                {qType === 'diagram_analysis' && (
                  <div className="preview-diagram-render mb-12">
                    <QuizDiagram 
                      type={diagramType} 
                      customNodes={qCustomNodes} 
                      customTitle={qCustomTitle} 
                      imageUrl={qImageUrl} 
                      imageCaption={qImageCaption} 
                    />
                  </div>
                )}

                {/* Multiple Choice Tiles Preview */}
                {(qType === 'multiple_choice' || qType === 'diagram_analysis') && (
                  <div className="grid-2-col gap-6 mb-12 text-2xs">
                    {mcOptions.map((opt, oIdx) => (
                      <div 
                        key={oIdx} 
                        className={`p-6 rounded border flex-between ${oIdx === mcCorrectIdx ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-bold' : 'bg-slate-50 text-slate-600'}`}
                      >
                        <span className="truncate">{String.fromCharCode(65 + oIdx)}. {opt || `Option ${oIdx + 1}`}</span>
                        {oIdx === mcCorrectIdx && <Check size={12} className="text-emerald font-bold flex-shrink-0" />}
                      </div>
                    ))}
                  </div>
                )}

                {/* Matching Preview */}
                {qType === 'matching' && (
                  <div className="preview-matching-list space-y-2 mb-12 text-2xs">
                    {matchingPairs.filter(p => p.left || p.right).map((p, pIdx) => (
                      <div key={pIdx} className="p-6 bg-slate-50 rounded border flex-align gap-6">
                        <span className="font-bold text-purple">{pIdx + 1}. {p.left || 'Term'}</span>
                        <span className="text-secondary font-bold">➔</span>
                        <span className="font-bold text-cyan">[{String.fromCharCode(65 + pIdx)}] {p.right || 'Definition'}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Identification Preview */}
                {qType === 'identification' && (
                  <div className="preview-ident-box mb-12">
                    <input 
                      type="text" 
                      className="clean-input w-full text-xs bg-slate-100" 
                      placeholder={identPlaceholder || "Type answer..."} 
                      disabled 
                    />
                    {identAnswers && (
                      <div className="text-2xs text-secondary mt-4">
                        Accepted: <strong className="text-purple">{identAnswers}</strong>
                      </div>
                    )}
                  </div>
                )}

                {/* Sequence Preview */}
                {qType === 'sequence_order' && (
                  <div className="preview-seq-list space-y-2 mb-12 text-2xs">
                    {seqSteps.filter(Boolean).map((s, sIdx) => (
                      <div key={sIdx} className="p-6 bg-slate-50 rounded border flex-align gap-6">
                        <span className="step-num-pill">{sIdx + 1}</span>
                        <span>{s}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Explanation Snippet */}
                {qExplanation && (
                  <div className="p-8 bg-purple-50 rounded border border-purple-200 text-2xs text-purple-900 flex-align gap-6">
                    <HelpCircle size={14} className="text-purple flex-shrink-0" />
                    <span>{qExplanation}</span>
                  </div>
                )}
              </div>

              {/* ASSESSMENT RULES & SCORING */}
              <div className="card p-16 mb-16 bg-slate-50 border border-slate-200 text-xs">
                <h4 className="font-bold text-slate-800 mb-8 uppercase tracking-wider text-2xs">
                  Assessment Context & Scoring Rules
                </h4>
                <div className="space-y-2 text-secondary">
                  <div className="flex-between">
                    <span>Curriculum Module:</span>
                    <strong className="text-slate-800">{selectedQuiz?.title}</strong>
                  </div>
                  <div className="flex-between">
                    <span>Countdown per Question:</span>
                    <strong className="text-purple">{selectedQuiz?.timePerQuestion}s</strong>
                  </div>
                  <div className="flex-between">
                    <span>Passing Standard:</span>
                    <strong className="text-emerald">{selectedQuiz?.passingScore}%</strong>
                  </div>
                  <div className="flex-between">
                    <span>Question Base Points:</span>
                    <strong className="text-amber">+200 PTS (+ Speed Bonus)</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // STANDARD ASSESSMENT OVERVIEW VIEW (Quiz Selection & Question Pool)
  // =========================================================================
  return (
    <div className="quiz-studio-layout">
      {toastMessage && (
        <div className="card notice-box mb-16 flex-between animate-fadeIn">
          <div className="flex-align gap-8">
            <CheckCircle2 size={16} className="text-emerald" />
            <span className="font-semibold text-sm">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* TOP ACTION HEADER */}
      <div className="studio-top-bar flex-between mb-20">
        <div>
          <h2 className="studio-main-title flex-align gap-10">
            <Sparkles className="text-purple" size={24} />
            <span>Quiz & Assessment Creator Studio</span>
          </h2>
          <p className="studio-subtitle text-secondary text-sm">
            Author and edit custom questions across all 5 interactive types (Matching, Kahoot tiles, Identification, Sequences, Diagrams).
          </p>
        </div>

        <div className="flex-align gap-10">
          <button 
            type="button" 
            className="btn btn-secondary btn-sm"
            onClick={handleResetDefaults}
            title="Restore syllabus default question bank"
          >
            <RotateCcw size={14} />
            <span>Reset to Defaults</span>
          </button>

          <button 
            type="button" 
            className="btn btn-primary btn-sm flex-align gap-6"
            onClick={() => setShowNewQuizModal(true)}
          >
            <Plus size={15} />
            <span>Create New Quiz</span>
          </button>
        </div>
      </div>

      <div className="studio-grid-container">
        {/* LEFT PANE: QUIZ SELECTOR ROSTER */}
        <div className="studio-sidebar-pane">
          <div className="pane-header flex-between mb-12">
            <span className="pane-title text-xs font-bold text-secondary uppercase tracking-wider">
              Course Assessments ({Object.keys(quizDb).length})
            </span>
          </div>

          <div className="quiz-selection-list">
            {Object.values(quizDb).map((q) => {
              const isSelected = q.id === selectedQuizId;
              const qCount = q.questions ? q.questions.length : 0;

              return (
                <div
                  key={q.id}
                  className={`quiz-selector-card ${isSelected ? 'selected-quiz-card' : ''}`}
                  onClick={() => handleSelectQuiz(q.id)}
                  style={{ borderLeftColor: q.headerColor || '#772ce8' }}
                >
                  <div className="flex-between mb-6">
                    <span className="quiz-category-chip" style={{ color: q.headerColor || '#772ce8' }}>
                      {q.category}
                    </span>
                    <span className="quiz-count-pill">{qCount} Qs</span>
                  </div>

                  <h4 className="quiz-card-title">{q.title}</h4>

                  <div className="quiz-card-footer flex-between mt-8 text-xs text-secondary">
                    <span className="flex-align gap-4">
                      <Clock size={11} /> {q.timePerQuestion}s/Q
                    </span>
                    <span className="flex-align gap-4">
                      <Award size={11} /> Pass: {q.passingScore}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT PANE: ACTIVE ASSESSMENT DETAILS & QUESTIONS POOL */}
        <div className="studio-main-pane">
          {selectedQuiz && (
            <>
              {/* QUIZ BANNER & STATS */}
              <div className="quiz-banner-card card mb-20" style={{ borderTop: `4px solid ${selectedQuiz.headerColor || '#772ce8'}` }}>
                <div className="flex-between mb-8">
                  <div className="flex-align gap-8">
                    <span className="badge badge-purple">{selectedQuiz.category}</span>
                    <span className="badge badge-blue">Instructor: {selectedQuiz.instructor}</span>
                  </div>
                  <div className="flex-align gap-8">
                    <span className="badge badge-green font-bold">
                      {selectedQuiz.questions ? selectedQuiz.questions.length : 0} Questions in Bank
                    </span>
                    <button
                      type="button"
                      className="btn btn-secondary btn-xs flex-align gap-4"
                      onClick={handleOpenEditQuizModal}
                      title="Edit assessment title, duration & passing threshold"
                    >
                      <Settings size={12} />
                      <span>Edit Quiz Settings</span>
                    </button>
                  </div>
                </div>

                <h3 className="quiz-banner-heading">{selectedQuiz.title}</h3>
                <p className="text-secondary text-sm mb-16">{selectedQuiz.description}</p>

                <div className="quiz-metrics-bar flex-between pt-12 border-top">
                  <div className="flex-align gap-16 text-xs text-secondary">
                    <span className="flex-align gap-6">
                      <Clock size={13} className="text-purple" />
                      <strong>Time Limit:</strong> {selectedQuiz.timePerQuestion} seconds / Question
                    </span>
                    <span className="flex-align gap-6">
                      <Award size={13} className="text-gold" />
                      <strong>Passing Threshold:</strong> {selectedQuiz.passingScore}%
                    </span>
                    <span className="flex-align gap-6">
                      {selectedQuiz.showCorrectAnswers !== false ? (
                        <span className="badge badge-emerald text-xs flex-align gap-4" title="Trainees can view answers and solutions in results review">
                          <Eye size={12} /> Solutions Visible
                        </span>
                      ) : (
                        <span className="badge badge-amber text-xs flex-align gap-4" title="Trainees can see submitted answers but solutions are kept hidden">
                          <Lock size={12} /> Solutions Hidden
                        </span>
                      )}
                    </span>
                  </div>

                  <button 
                    type="button" 
                    className="btn btn-primary btn-sm flex-align gap-6"
                    onClick={handleOpenAddModal}
                  >
                    <Plus size={15} />
                    <span>Add Question to Assessment</span>
                  </button>
                </div>
              </div>

              {/* QUESTIONS POOL LIST */}
              <div className="questions-pool-container">
                <div className="flex-between mb-12">
                  <h4 className="font-bold text-sm text-secondary uppercase tracking-wider">
                    Question Items Pool ({selectedQuiz.questions ? selectedQuiz.questions.length : 0})
                  </h4>
                  <span className="text-xs text-secondary">Interactive editing & real-time pool updates</span>
                </div>

                {(!selectedQuiz.questions || selectedQuiz.questions.length === 0) ? (
                  <div className="card text-center p-32 text-secondary">
                    <FileQuestion size={40} className="mx-auto mb-12 text-secondary opacity-50" />
                    <h4>No Questions in This Assessment</h4>
                    <p className="text-sm mb-16">Click below to author the first question item.</p>
                    <button 
                      type="button" 
                      className="btn btn-primary btn-sm"
                      onClick={handleOpenAddModal}
                    >
                      <Plus size={14} /> Add First Question
                    </button>
                  </div>
                ) : (
                  <div className="questions-stack">
                    {selectedQuiz.questions.map((q, idx) => {
                      const typeConfig = QUESTION_TYPES.find(t => t.id === q.type) || QUESTION_TYPES[0];
                      const TypeIcon = typeConfig.icon;

                      return (
                        <div key={q.id || idx} className="card question-pool-card mb-12">
                          <div className="flex-between mb-8">
                            <div className="flex-align gap-8">
                              <span className="question-seq-num">#{idx + 1}</span>
                              <span className={`type-tag ${typeConfig.badgeClass}`}>
                                <TypeIcon size={12} />
                                <span>{typeConfig.label}</span>
                              </span>
                            </div>

                            {/* EDIT AND DELETE ACTIONS */}
                            <div className="flex-align gap-6">
                              <button 
                                type="button" 
                                className="btn-icon-secondary"
                                onClick={() => handleOpenEditModal(q, idx)}
                                title="Edit this question"
                              >
                                <Edit3 size={14} />
                              </button>
                              <button 
                                type="button" 
                                className="btn-icon-danger"
                                onClick={() => handleDeleteQuestion(q.id)}
                                title="Delete question from quiz"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>

                          <div className="question-prompt-text font-semibold text-sm mb-12 text-slate-800">
                            {q.question}
                          </div>

                          {/* Attached image preview in question pool card */}
                          {q.imageUrl && (
                            <div className="pool-image-preview flex-align gap-10 p-8 bg-slate-50 rounded border border-slate-200 mb-10">
                              <img src={q.imageUrl} alt="Reference Graphic" className="pool-thumbnail-img" />
                              <div className="text-xs text-secondary">
                                <span className="font-bold text-purple">Attached Graphic: </span>
                                <span>{q.imageCaption || (q.type === 'diagram_analysis' ? 'Custom Diagram Image' : 'Question Image Reference')}</span>
                              </div>
                            </div>
                          )}

                          {/* Preview Details Based on Type */}
                          {q.type === 'multiple_choice' && Array.isArray(q.options) && (
                            <div className="grid-2-col gap-8 mb-10 text-xs">
                              {q.options.map((opt, oIdx) => (
                                <div 
                                  key={oIdx} 
                                  className={`p-6 rounded border flex-between ${oIdx === q.correctAnswer ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold' : 'bg-slate-50 text-slate-600'}`}
                                >
                                  <span>{String.fromCharCode(65 + oIdx)}. {opt}</span>
                                  {oIdx === q.correctAnswer && <Check size={12} className="text-emerald font-bold" />}
                                </div>
                              ))}
                            </div>
                          )}

                          {q.type === 'matching' && Array.isArray(q.pairs) && (
                            <div className="matching-preview-pairs mb-10 text-xs">
                              {q.pairs.map((p, pIdx) => (
                                <div key={p.id || pIdx} className="matching-pair-row flex-align gap-8 p-6 bg-slate-50 rounded mb-4 border border-slate-200">
                                  <span className="font-semibold text-purple">{pIdx + 1}. {p.left}</span>
                                  <span className="text-secondary font-bold">➔</span>
                                  <span className="font-semibold text-cyan">[{String.fromCharCode(65 + pIdx)}] {p.right}</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {q.type === 'identification' && (
                            <div className="ident-preview-box mb-10 text-xs p-8 bg-slate-50 rounded border border-slate-200">
                              <span className="text-secondary">Accepted Solutions: </span>
                              <strong className="text-purple">{(q.acceptedAnswers || []).join(' | ')}</strong>
                            </div>
                          )}

                          {q.type === 'sequence_order' && Array.isArray(q.correctOrder) && (
                            <div className="seq-preview-steps mb-10 text-xs">
                              {q.correctOrder.map((step, sIdx) => (
                                <div key={sIdx} className="seq-preview-item flex-align gap-6 p-4 text-slate-700">
                                  <span className="step-num-pill">{sIdx + 1}</span>
                                  <span>{step}</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {q.type === 'diagram_analysis' && (
                            <div className="diagram-preview-box mb-10 text-xs p-6 bg-slate-50 rounded border border-slate-200 flex-between flex-wrap gap-6">
                              <span className="text-secondary">
                                Diagram Architecture: <strong>
                                  {q.diagramSource === 'image' || q.imageUrl
                                    ? 'Uploaded Custom Graphic' 
                                    : q.diagramSource === 'custom_flow' || q.customNodes
                                    ? `Custom Pipeline (${q.customNodes?.length || 4} Nodes)`
                                    : (q.diagramType || 'security_pipeline')}
                                </strong>
                              </span>
                              <span className="text-emerald font-semibold">Correct Solution: {q.options ? q.options[q.correctAnswer] : ''}</span>
                            </div>
                          )}

                          {/* Explanation footer */}
                          {q.explanation && (
                            <div className="question-explanation-text text-xs text-secondary pt-8 border-top flex-align gap-6">
                              <HelpCircle size={12} className="text-purple flex-shrink-0" />
                              <span>{q.explanation}</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>



      {/* =========================================================================
          MODAL: EDIT QUIZ SETTINGS / METADATA
          ========================================================================= */}
      {showEditQuizModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-md animate-scaleIn">
            <div className="modal-header flex-between">
              <div>
                <h3 className="modal-title flex-align gap-8">
                  <Settings size={18} className="text-purple" />
                  <span>Edit Assessment Settings</span>
                </h3>
                <p className="text-secondary text-xs">
                  Update syllabus details, countdown timers, and certification criteria.
                </p>
              </div>
              <button 
                type="button" 
                className="btn-icon-ghost"
                onClick={() => setShowEditQuizModal(false)}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuizMetadata} className="modal-form-body p-20">
              <div className="form-group mb-12">
                <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                  Assessment Title
                </label>
                <input
                  type="text"
                  className="clean-input w-full"
                  required
                  value={quizMetaForm.title}
                  onChange={(e) => setQuizMetaForm({ ...quizMetaForm, title: e.target.value })}
                />
              </div>

              <div className="grid-2-col gap-12 mb-12">
                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Category
                  </label>
                  <input
                    type="text"
                    className="clean-input w-full"
                    value={quizMetaForm.category}
                    onChange={(e) => setQuizMetaForm({ ...quizMetaForm, category: e.target.value })}
                  />
                </div>

                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Color Accent
                  </label>
                  <select 
                    className="clean-input w-full"
                    value={quizMetaForm.headerColor}
                    onChange={(e) => setQuizMetaForm({ ...quizMetaForm, headerColor: e.target.value })}
                  >
                    <option value="#772ce8">Purple (Security & Zero-Trust)</option>
                    <option value="#1368ce">Blue (Enterprise Audit)</option>
                    <option value="#06d6a0">Emerald (Access Control)</option>
                    <option value="#e21b3c">Crimson (Privacy Management)</option>
                    <option value="#d89e00">Gold (Compliance Standard)</option>
                  </select>
                </div>
              </div>

              <div className="grid-2-col gap-12 mb-12">
                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Time Per Question (Seconds)
                  </label>
                  <input
                    type="number"
                    min="15"
                    max="180"
                    className="clean-input w-full"
                    value={quizMetaForm.timePerQuestion}
                    onChange={(e) => setQuizMetaForm({ ...quizMetaForm, timePerQuestion: e.target.value })}
                  />
                </div>

                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Passing Standard (%)
                  </label>
                  <input
                    type="number"
                    min="50"
                    max="100"
                    className="clean-input w-full"
                    value={quizMetaForm.passingScore}
                    onChange={(e) => setQuizMetaForm({ ...quizMetaForm, passingScore: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-group mb-16">
                <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                  Assessment Background & Syllabus Scope
                </label>
                <textarea
                  className="clean-input w-full"
                  rows={3}
                  value={quizMetaForm.description}
                  onChange={(e) => setQuizMetaForm({ ...quizMetaForm, description: e.target.value })}
                />
              </div>

              <div className="form-group mb-16 p-12 bg-neutral-surface border-rounded" style={{ border: '1px solid var(--border-color, #e2e8f0)', borderRadius: '10px' }}>
                <label className="flex-align gap-10 cursor-pointer" style={{ margin: 0 }}>
                  <input
                    type="checkbox"
                    checked={quizMetaForm.showCorrectAnswers !== false}
                    onChange={(e) => setQuizMetaForm({ ...quizMetaForm, showCorrectAnswers: e.target.checked })}
                    style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary, #772ce8)', cursor: 'pointer' }}
                  />
                  <div>
                    <div className="font-semibold text-sm">Reveal Correct Solutions in Results Review</div>
                    <div className="text-secondary text-xs">
                      When disabled, participants can inspect their submitted answers, but correct keys and explanations remain hidden.
                    </div>
                  </div>
                </label>
              </div>

              <div className="modal-actions flex-between pt-16 border-top">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowEditQuizModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary flex-align gap-6"
                >
                  <Save size={15} />
                  <span>Save Assessment Settings</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: CREATE NEW QUIZ
          ========================================================================= */}
      {showNewQuizModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-md animate-scaleIn">
            <div className="modal-header flex-between">
              <div>
                <h3 className="modal-title flex-align gap-8">
                  <BookOpen size={18} className="text-purple" />
                  <span>Create New Course Assessment</span>
                </h3>
                <p className="text-secondary text-xs">
                  Create a new certified module curriculum for client cohorts.
                </p>
              </div>
              <button 
                type="button" 
                className="btn-icon-ghost"
                onClick={() => setShowNewQuizModal(false)}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewQuiz} className="modal-form-body p-20">
              <div className="form-group mb-12">
                <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                  Assessment Title
                </label>
                <input
                  type="text"
                  className="clean-input w-full"
                  required
                  placeholder="e.g. Advanced Incident Containment & Forensics"
                  value={newQuizTitle}
                  onChange={(e) => setNewQuizTitle(e.target.value)}
                />
              </div>

              <div className="grid-2-col gap-12 mb-12">
                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Category
                  </label>
                  <input
                    type="text"
                    className="clean-input w-full"
                    placeholder="e.g. Incident Response"
                    value={newQuizCategory}
                    onChange={(e) => setNewQuizCategory(e.target.value)}
                  />
                </div>

                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Header Color Theme
                  </label>
                  <select 
                    className="clean-input w-full"
                    value={newQuizColor}
                    onChange={(e) => setNewQuizColor(e.target.value)}
                  >
                    <option value="#772ce8">Purple (Security & Cryptography)</option>
                    <option value="#1368ce">Blue (Enterprise Audit)</option>
                    <option value="#06d6a0">Emerald (Access Control)</option>
                    <option value="#e21b3c">Crimson (Privacy Management)</option>
                    <option value="#d89e00">Gold (Compliance Standard)</option>
                  </select>
                </div>
              </div>

              <div className="grid-2-col gap-12 mb-12">
                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Time Per Question (Seconds)
                  </label>
                  <input
                    type="number"
                    min="15"
                    max="180"
                    className="clean-input w-full"
                    value={newQuizTime}
                    onChange={(e) => setNewQuizTime(e.target.value)}
                  />
                </div>

                <div>
                  <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                    Passing Score Standard (%)
                  </label>
                  <input
                    type="number"
                    min="50"
                    max="100"
                    className="clean-input w-full"
                    value={newQuizPassing}
                    onChange={(e) => setNewQuizPassing(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group mb-16">
                <label className="field-label text-xs mb-4 font-bold text-secondary uppercase">
                  Assessment Background & Objectives
                </label>
                <textarea
                  className="clean-input w-full"
                  rows={3}
                  placeholder="Outline the scenario, threat landscape, and target security capabilities tested in this assessment..."
                  value={newQuizDesc}
                  onChange={(e) => setNewQuizDesc(e.target.value)}
                />
              </div>

              <div className="form-group mb-16 p-12 bg-neutral-surface border-rounded" style={{ border: '1px solid var(--border-color, #e2e8f0)', borderRadius: '10px' }}>
                <label className="flex-align gap-10 cursor-pointer" style={{ margin: 0 }}>
                  <input
                    type="checkbox"
                    checked={newQuizShowCorrectAnswers}
                    onChange={(e) => setNewQuizShowCorrectAnswers(e.target.checked)}
                    style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary, #772ce8)', cursor: 'pointer' }}
                  />
                  <div>
                    <div className="font-semibold text-sm">Reveal Correct Solutions in Results Review</div>
                    <div className="text-secondary text-xs">
                      When disabled, participants can inspect their submitted answers, but correct keys and explanations remain hidden.
                    </div>
                  </div>
                </label>
              </div>

              <div className="modal-actions flex-between pt-16 border-top">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowNewQuizModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary flex-align gap-6"
                >
                  <Save size={15} />
                  <span>Publish Assessment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
