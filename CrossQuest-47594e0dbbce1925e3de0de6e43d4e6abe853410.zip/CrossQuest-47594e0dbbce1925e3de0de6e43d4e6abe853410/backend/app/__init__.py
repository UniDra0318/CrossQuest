"""CrossQuest Backend Application Package."""
