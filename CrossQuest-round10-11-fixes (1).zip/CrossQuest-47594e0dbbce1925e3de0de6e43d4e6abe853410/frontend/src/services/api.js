export function triggerBlobDownload(blob, filename) {
  const blobUrl = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    try {
      if (link.parentNode) link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (e) {
      // ignore cleanup error
    }
  }, 2000);
}

const API_BASE = 'http://localhost:8000/api/v1';

/**
 * Helper to check whether a JWT token has expired or is about to expire (15s buffer).
 */
export function isTokenExpired(tokenStr) {
  if (!tokenStr) return true;
  try {
    const parts = tokenStr.split('.');
    if (parts.length !== 3) return true;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const jsonStr = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    const payload = JSON.parse(jsonStr);
    if (!payload.exp) return false;
    return (payload.exp * 1000) < (Date.now() + 15000);
  } catch {
    return true;
  }
}

export const SESSION_EXPIRED_EVENT = 'crossquest_session_expired';
const emitExpired = (reason) => {
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT, { detail: { reason } }));
};
const IDLE_RE = /inactiv|timed out|idle/i;

/** Renews the 10-min access token via the server refresh cookie. Server enforces idle + 12h max (SEC-07, OI-17). */
export async function refreshAuthToken() {
  try {
    const res = await fetch(`${API_BASE}/auth/refresh`, {
      method: 'POST', credentials: 'include', headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    if (res.ok) {
      const d = await res.json();
      if (d.access_token) {
        localStorage.setItem('crossquest_auth_token', d.access_token);
        window.dispatchEvent(new CustomEvent('crossquest_token_refreshed', { detail: { token: d.access_token } }));
        return d.access_token;
      }
    }
    if (res.status === 401 || res.status === 403) {
      let detail = ''; try { detail = (await res.json()).detail || ''; } catch {}
      emitExpired(IDLE_RE.test(detail) ? 'idle' : 'expired');
    }
  } catch (e) { console.warn('Token refresh failed:', e); }
  return null;
}

/** Authenticated fetch. NEVER silently re-logs in: a timed-out/revoked session ends at /login. */
export async function authFetch(url, options = {}, token) {
  let activeToken = token || localStorage.getItem('crossquest_auth_token');
  if (!activeToken || isTokenExpired(activeToken)) activeToken = await refreshAuthToken();
  if (!activeToken) return new Response(JSON.stringify({ detail: 'Session expired' }), { status: 401 });

  const headers = { ...(options.headers || {}), Authorization: `Bearer ${activeToken}` };
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 20000);
  let res;
  try {
    res = await fetch(url, { ...options, headers, signal: options.signal || controller.signal });
  } finally { clearTimeout(timeoutId); }

  if (res.status === 401) {
    let detail = ''; try { detail = (await res.clone().json()).detail || ''; } catch {}
    if (/timed out|inactiv|revoked|logged out|maximum/i.test(detail)) {
      emitExpired(IDLE_RE.test(detail) ? 'idle' : 'expired');
    } else {
      const fresh = await refreshAuthToken();
      if (fresh) { headers.Authorization = `Bearer ${fresh}`; res = await fetch(url, { ...options, headers }); }
    }
  }
  return res;
}


export async function fetchCompanies(token) {
  try {
    const res = await authFetch(`${API_BASE}/trainees/companies`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for companies:", err);
  }
  return null;
}

export async function fetchTrainees(token) {
  try {
    const res = await authFetch(`${API_BASE}/trainees/`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for trainees:", err);
  }
  return null;
}

export async function fetchRecords(token) {
  try {
    const res = await authFetch(`${API_BASE}/records/`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for records:", err);
  }
  return null;
}

export async function createEncryptedRecordApi(recordData, token) {
  try {
    const res = await fetch(`${API_BASE}/records/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify(recordData)
    });
    const data = await res.json();
    return { ok: res.ok, data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}


export async function decryptRecordApi(recordId, token) {
  try {
    const res = await authFetch(`${API_BASE}/records/${recordId}/decrypt`, {
      method: 'POST'
    }, token);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, status: res.status, error: data.detail || `Decryption failed (${res.status})` };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, status: err.status || 500, error: err.message };
  }
}

export async function fetchAnomalies(token) {
  try {
    const res = await authFetch(`${API_BASE}/anomalies/alerts`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for anomalies:", err);
  }
  return null;
}

export async function fetchLeaderboard() {
  try {
    const res = await fetch(`${API_BASE}/gamification/leaderboard`);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for leaderboard:", err);
  }
  return null;
}

export async function fetchClassLeaderboard(sessionId, token) {
  try {
    const headers = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/gamification/leaderboard/class?session_id=${encodeURIComponent(sessionId)}`, { headers });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for class leaderboard:", err);
  }
  return null;
}

export async function fetchCompanyLeaderboard(token) {
  try {
    const headers = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/gamification/leaderboard/company`, { headers });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for company leaderboard:", err);
  }
  return null;
}

export async function toggleLeaderboardOptOut(optOut, token) {
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/gamification/profile/leaderboard-opt-out`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ opt_out: optOut })
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error updating leaderboard opt-out:", err);
  }
  return null;
}

export async function fetchTraineeGamification(traineeId, token) {
  try {
    const headers = {};
    const authToken = token || (typeof localStorage !== 'undefined' ? localStorage.getItem('crossquest_auth_token') : null);
    if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);
    const res = await fetch(`${API_BASE}/gamification/trainee/${traineeId}`, {
      headers,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for trainee gamification:", err);
  }
  return null;
}

export async function submitQuizScore(traineeId, quizId, score, token) {
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/gamification/submit-quiz`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ 
        trainee_id: traineeId,
        quiz_id: quizId || 'act-1',
        score: Number(score) || 100,
        attempt_id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `att-${Date.now()}`
      })
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for submit-quiz:", err);
  }
  return null;
}

export async function submitQuizAttempt(payload, token) {
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE}/gamification/submit-quiz`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error submitting quiz attempt:", err);
  }
  return null;
}

export async function fetchStaffUsers(token) {
  try {
    const res = await authFetch(`${API_BASE}/users/`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for staff users:", err);
  }
  return null;
}

export async function fetchTrainers(token) {
  try {
    const res = await authFetch(`${API_BASE}/users/trainers`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for trainers:", err);
  }
  return [];
}

export async function updateStaffAttributes(userId, attrs, token) {
  try {
    const res = await fetch(`${API_BASE}/users/${userId}/attributes`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify(attrs)
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error updating staff attributes:", err);
  }
  return null;
}

export async function fetchTrainerSessions(token) {
  try {
    const res = await authFetch(`${API_BASE}/records/sessions/assigned`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for trainer sessions:", err);
  }
  return null;
}

export async function submitTrainerSignOff(sessionId, payload, token) {
  const res = await fetch(`${API_BASE}/records/sessions/${sessionId}/sign-off`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Sign-off failed (${res.status})`);
  }
  return data;
}

export async function enrollTraineeInSessionApi(sessionId, payload, token) {
  const res = await authFetch(`${API_BASE}/records/sessions/${sessionId}/enroll`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  }, token);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Enrollment failed (${res.status})`);
  }
  return data;
}

export async function fetchImportBatches(token) {
  try {
    const res = await authFetch(`${API_BASE}/imports/batches`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for import batches:", err);
  }
  return null;
}

export async function uploadImportFile(file, token) {
  const formData = new FormData();
  formData.append('file', file);
  const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
  const endpoint = isExcel ? `${API_BASE}/imports/upload-workbook` : `${API_BASE}/imports/upload`;
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: token ? { 'Authorization': `Bearer ${token}` } : {},
    body: formData
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `File upload failed (${res.status})`);
  }
  return data;
}

export async function fetchBatchDiscrepancies(batchId, token) {
  try {
    const res = await authFetch(`${API_BASE}/imports/batches/${batchId}/discrepancies`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for batch discrepancies:", err);
  }
  return null;
}

export async function resolveDiscrepancy(discrepancyId, payload, token) {
  const res = await fetch(`${API_BASE}/imports/discrepancies/${discrepancyId}/resolve`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Resolution failed (${res.status})`);
  }
  return data;
}

export async function fetchReconciliationReport(batchId, token) {
  try {
    const res = await authFetch(`${API_BASE}/imports/batches/${batchId}/reconciliation`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for reconciliation report:", err);
  }
  return null;
}

export async function commitImportBatch(batchId, token) {
  const res = await fetch(`${API_BASE}/imports/batches/${batchId}/commit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Commit batch failed (${res.status})`);
  }
  return data;
}

export async function fetchCertificationTypes(token) {
  try {
    const res = await fetch(`${API_BASE}/certifications/types`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for cert types:", err);
  }
  return null;
}

export async function fetchCertificates(token) {
  try {
    const res = await fetch(`${API_BASE}/certifications/`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for certificates:", err);
  }
  return null;
}

export async function fetchMyTrainingRecords(token) {
  try {
    const res = await fetch(`${API_BASE}/records/`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for records:", err);
  }
  return null;
}

export async function submitExternalCredential(payload, token) {
  const res = await fetch(`${API_BASE}/certifications/external-renewal`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `External credential submission failed (${res.status})`);
  }
  return data;
}

export async function fetchExpiryNotifications(token) {
  try {
    const res = await fetch(`${API_BASE}/certifications/notifications`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for notifications:", err);
  }
  return null;
}

export async function triggerExpirySweep(token) {
  const res = await fetch(`${API_BASE}/certifications/trigger-sweep`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Sweep trigger failed (${res.status})`);
  }
  return data;
}

export async function downloadCertificatePdf(certificateId, token) {
  const authToken = token || localStorage.getItem('crossquest_auth_token');
  const res = await fetch(`${API_BASE}/certifications/${encodeURIComponent(certificateId)}/pdf`, {
    headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {}
  });
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to download certificate PDF (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Certificate_${certificateId}.pdf`);
  return true;
}

export async function downloadBatchReconciliationPdf(batchId, token) {
  const authToken = token || localStorage.getItem('crossquest_auth_token');
  const res = await fetch(`${API_BASE}/imports/batches/${encodeURIComponent(batchId)}/reconciliation/pdf`, {
    headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {}
  });
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to download reconciliation PDF (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Finance_Reconciliation_Batch_${batchId.slice(0, 8)}.pdf`);
  return true;
}

export async function downloadBatchReconciliationCsv(batchId, token) {
  const authToken = token || localStorage.getItem('crossquest_auth_token');
  const res = await fetch(`${API_BASE}/imports/batches/${encodeURIComponent(batchId)}/reconciliation/csv`, {
    headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {}
  });
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to download reconciliation CSV (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Finance_Reconciliation_Batch_${batchId.slice(0, 8)}.csv`);
  return true;
}

export async function fetchAssignedClientCompanies(token) {
  try {
    const res = await authFetch(`${API_BASE}/reports/assigned-companies`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for assigned companies:", err);
  }
  return null;
}

export async function fetchClientReport(companyCode, { startDate, endDate, statusFilter } = {}, token) {
  const query = new URLSearchParams();
  if (startDate) query.append('start_date', startDate);
  if (endDate) query.append('end_date', endDate);
  if (statusFilter && statusFilter !== 'ALL') query.append('status_filter', statusFilter);
  const qStr = query.toString() ? `?${query.toString()}` : '';

  const res = await authFetch(`${API_BASE}/reports/company/${encodeURIComponent(companyCode)}${qStr}`, {}, token);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(data.detail || `Failed to fetch client report (${res.status})`);
    error.status = res.status;
    throw error;
  }
  return data;
}

export async function downloadClientReportPdf(companyCode, { startDate, endDate, statusFilter } = {}, token) {
  const query = new URLSearchParams();
  if (startDate) query.append('start_date', startDate);
  if (endDate) query.append('end_date', endDate);
  if (statusFilter && statusFilter !== 'ALL') query.append('status_filter', statusFilter);
  const qStr = query.toString() ? `?${query.toString()}` : '';

  const res = await authFetch(`${API_BASE}/reports/company/${encodeURIComponent(companyCode)}/pdf${qStr}`, {}, token);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to download report PDF (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Training_Report_${companyCode.toUpperCase()}.pdf`);
  return true;
}

export async function downloadClientReportCsv(companyCode, { startDate, endDate, statusFilter } = {}, token) {
  const query = new URLSearchParams();
  if (startDate) query.append('start_date', startDate);
  if (endDate) query.append('end_date', endDate);
  if (statusFilter && statusFilter !== 'ALL') query.append('status_filter', statusFilter);
  const qStr = query.toString() ? `?${query.toString()}` : '';

  const res = await authFetch(`${API_BASE}/reports/company/${encodeURIComponent(companyCode)}/csv${qStr}`, {}, token);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to export report CSV (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Training_Report_${companyCode.toUpperCase()}.csv`);
  return true;
}

export async function downloadClientReportExcel(companyCode, { startDate, endDate, statusFilter } = {}, token) {
  const query = new URLSearchParams();
  if (startDate) query.append('start_date', startDate);
  if (endDate) query.append('end_date', endDate);
  if (statusFilter && statusFilter !== 'ALL') query.append('status_filter', statusFilter);
  query.append('format', 'excel');
  const qStr = `?${query.toString()}`;

  const res = await authFetch(`${API_BASE}/reports/company/${encodeURIComponent(companyCode)}/export${qStr}`, {}, token);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to export report Excel (${res.status})`);
  }
  const blob = await res.blob();
  triggerBlobDownload(blob, `Training_Report_${companyCode.toUpperCase()}.xlsx`);
  return true;
}

export async function reviewAnomalyAlert(alertId, reviewData, token) {
  const res = await fetch(`${API_BASE}/anomalies/alerts/${alertId}/review`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(reviewData)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Review failed (${res.status})`);
  }
  return data;
}

export async function fetchAccessLogs(limit = 100, token) {
  try {
    const res = await fetch(`${API_BASE}/anomalies/logs?limit=${limit}`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for access logs:", err);
  }
  return null;
}

export async function fetchAnomalyRules(token) {
  try {
    const res = await fetch(`${API_BASE}/anomalies/rules`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for anomaly rules:", err);
  }
  return null;
}

export async function updateAnomalyRule(ruleCode, ruleData, token) {
  const res = await fetch(`${API_BASE}/anomalies/rules/${encodeURIComponent(ruleCode)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(ruleData)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Failed to update rule (${res.status})`);
  }
  return data;
}

export async function batchUpdateAnomalyRules(batchData, token) {
  const res = await fetch(`${API_BASE}/anomalies/rules-batch`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify(batchData)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Failed to batch update rules (${res.status})`);
  }
  return data;
}

export async function approveAnomalyRule(ruleCode, reason, token) {
  const res = await fetch(`${API_BASE}/anomalies/rules/${encodeURIComponent(ruleCode)}/approve`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify({ reason: reason || 'Peer review approval confirmed' })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Failed to approve rule (${res.status})`);
  }
  return data;
}

export async function batchApproveAnomalyRules(reason, token) {
  const res = await fetch(`${API_BASE}/anomalies/rules-batch/approve`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify({ reason: reason || 'Peer review approval confirmed for pending threshold changes' })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Failed to batch approve rules (${res.status})`);
  }
  return data;
}

export async function runRetentionJob(token) {
  const res = await fetch(`${API_BASE}/anomalies/retention/run`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: JSON.stringify({ retention_days: 365, warning_days: 30 })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Retention job failed (${res.status})`);
  }
  return data;
}


export async function fetchExecutiveAnomalyReport(token) {
  try {
    const res = await authFetch(`${API_BASE}/anomalies/report`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for anomaly report:", err);
  }
  return null;
}

export async function downloadAnomalyReportPdf(token) {
  try {
    const authToken = token || localStorage.getItem('crossquest_auth_token');
    const headers = {};
    if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
    const res = await fetch(`${API_BASE}/anomalies/report/pdf`, { headers });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    triggerBlobDownload(blob, `CrossQuest_Security_Anomaly_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
    return true;
  } catch (err) {
    console.warn("Failed to download anomaly report PDF:", err);
    return false;
  }
}

export async function downloadAnomalyReportCsv(token) {
  try {
    const authToken = token || localStorage.getItem('crossquest_auth_token');
    const headers = {};
    if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
    const res = await fetch(`${API_BASE}/anomalies/report/csv`, { headers });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    triggerBlobDownload(blob, `CrossQuest_Anomaly_Ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    return true;
  } catch (err) {
    console.warn("Failed to download anomaly report CSV:", err);
    return false;
  }
}

export async function fetchRetentionWarnings(token) {
  try {
    const res = await fetch(`${API_BASE}/anomalies/retention/warnings`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for retention warnings:", err);
  }
  return null;
}

export async function fetchCryptoPersonas() {
  try {
    const res = await fetch(`${API_BASE}/crypto-lab/personas`);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for crypto personas:", err);
  }
  return null;
}

export async function runCryptoSandboxEncrypt({ payload, policy, recordId, version } = {}) {
  const res = await fetch(`${API_BASE}/crypto-lab/encrypt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payload: payload || {},
      policy: policy || "ROLEADMIN",
      record_id: recordId || "REC-DEMO-001",
      version: version || 1
    })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Encryption failed (${res.status})`);
  }
  return data;
}

export async function runCryptoSandboxDecrypt({ encryptedRecord, userAttributes, recordId, version, simulateTamper } = {}) {
  const res = await fetch(`${API_BASE}/crypto-lab/decrypt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      encrypted_record: encryptedRecord,
      user_attributes: userAttributes || [],
      record_id: recordId || "REC-DEMO-001",
      version: version || 1,
      simulate_tamper: simulateTamper || "NONE"
    })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Decryption failed (${res.status})`);
  }
  return data;
}

export async function createCompanyApi(companyData, token) {
  try {
    const res = await fetch(`${API_BASE}/trainees/companies`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify(companyData)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, status: res.status, error: data.detail || 'Failed to create company' };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

export async function createUserApi(userData, token) {
  try {
    const res = await fetch(`${API_BASE}/users/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify(userData)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, status: res.status, error: data.detail || 'Failed to create user account' };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

export async function confirmPasswordResetApi({ token, new_password }) {
  try {
    const res = await fetch(`${API_BASE}/auth/confirm-reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, new_password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, status: res.status, error: data.detail || 'Failed to activate account' };
    }
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

export async function fetchSystemOverview(token) {
  try {
    const res = await authFetch(`${API_BASE}/users/overview`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for system overview:", err);
  }
  return null;
}

export async function fetchQuizzes(token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for quizzes:", err);
  }
  return [];
}

export async function fetchQuizQuestionsApi(quizId, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes/${quizId}/questions`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error fetching quiz questions:", err);
  }
  return [];
}

export async function createQuizApi(payload, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error creating quiz:", err);
  }
  return null;
}

export async function fetchQuizCoursesApi(token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quiz-courses`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error fetching quiz courses:", err);
  }
  return [];
}

export async function addQuizQuestionApi(quizId, payload, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes/${quizId}/questions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error adding quiz question:", err);
  }
  return null;
}

export async function updateQuizQuestionApi(quizId, questionId, payload, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes/${quizId}/questions/${questionId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API error updating quiz question:", err);
  }
  return null;
}

export async function deleteQuizQuestionApi(quizId, questionId, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes/${quizId}/questions/${questionId}`, {
      method: 'DELETE'
    }, token);
    return res.ok;
  } catch (err) {
    console.warn("API error deleting quiz question:", err);
    return false;
  }
}

export async function deleteQuizApi(quizId, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/quizzes/${quizId}`, {
      method: 'DELETE'
    }, token);
    return res.ok;
  } catch (err) {
    console.warn("API error deleting quiz:", err);
    return false;
  }
}

export async function exportAuditLogsCsv(token) {
  try {
    const authToken = token || localStorage.getItem('crossquest_auth_token');
    // First try dedicated backend CSV endpoint
    try {
      const resCsv = await fetch(`${API_BASE}/anomalies/logs/csv`, {
        headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {}
      });
      if (resCsv.ok) {
        const blob = await resCsv.blob();
        triggerBlobDownload(blob, `master-audit-logs-${Date.now()}.csv`);
        return true;
      }
    } catch (e) {
      console.warn("Backend logs CSV failed, trying JSON fallback:", e);
    }

    // Resilient fallback to JSON endpoint
    const res = await authFetch(`${API_BASE}/anomalies/logs?limit=500`, {}, token);
    if (!res.ok) throw new Error("Failed to load audit logs");
    const logs = await res.json();

    const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
    const head = ['log_id', 'occurred_at', 'actor_role', 'event_type', 'resource_type', 'resource_id', 'outcome', 'reason_code', 'source_ip'];
    const rows = (logs || []).map((l) => [
      l.id,
      l.occurred_at,
      l.actor_role,
      l.event_type,
      l.resource_type,
      l.resource_id,
      l.outcome,
      l.reason_code,
      l.source_ip
    ]);
    const text = [head, ...rows].map((r) => r.map(esc).join(',')).join('\n');
    const blob = new Blob([text], { type: 'text/csv;charset=utf-8;' });
    triggerBlobDownload(blob, `master-audit-logs-${Date.now()}.csv`);
    return true;
  } catch (err) {
    console.warn("Failed to export audit logs CSV:", err);
    return false;
  }
}

export async function exportVaultRecordsCsv(token) {
  try {
    const authToken = token || localStorage.getItem('crossquest_auth_token');
    try {
      const resCsv = await fetch(`${API_BASE}/records/export/csv`, {
        headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {}
      });
      if (resCsv.ok) {
        const blob = await resCsv.blob();
        triggerBlobDownload(blob, `master-training-records-${Date.now()}.csv`);
        return true;
      }
    } catch (e) {
      console.warn("Backend records export CSV failed, trying fallback:", e);
    }

    const res = await authFetch(`${API_BASE}/records`, {}, token);
    if (!res.ok) throw new Error("Failed to load records");
    const recs = await res.json();

    const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
    const head = ['record_id', 'course_name', 'status', 'score', 'completion_date', 'encryption_policy'];
    const rows = (recs || []).map((r) => [
      r.id,
      r.course_name,
      r.status,
      r.score,
      r.completion_date,
      r.encryption_policy
    ]);
    const text = [head, ...rows].map((r) => r.map(esc).join(',')).join('\n');
    const blob = new Blob([text], { type: 'text/csv;charset=utf-8;' });
    triggerBlobDownload(blob, `master-training-records-${Date.now()}.csv`);
    return true;
  } catch (err) {
    console.warn("Failed to export training records CSV:", err);
    return false;
  }
}

/**
 * MFA API functions: setup, enable, and verify Google Authenticator TOTP
 */
export async function setupMfaApi(token) {
  const res = await authFetch(`${API_BASE}/auth/mfa/setup`, { method: 'POST' }, token);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to initialize MFA setup');
  }
  return res.json();
}

export async function enableMfaApi(secret, code, token) {
  const res = await authFetch(
    `${API_BASE}/auth/mfa/enable`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secret, code })
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Invalid MFA verification code');
  }
  return res.json();
}

export async function verifyMfaLoginApi(challengeToken, code) {
  const res = await fetch(`${API_BASE}/auth/mfa/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ challenge_token: challengeToken, code })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Invalid MFA code or recovery code');
  }
  return res.json();
}

/** U-06: Reassign Trainee Company Affiliation */
export async function changeTraineeCompany(traineeId, data, token) {
  const res = await authFetch(
    `${API_BASE}/trainees/${traineeId}/change-company`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to update trainee company affiliation');
  }
  return res.json();
}

/** U-05: Correct/Update Training Record with mandatory reason */
export async function updateTrainingRecord(recordId, updateData, token) {
  const res = await authFetch(
    `${API_BASE}/records/${recordId}`,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updateData)
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to update training record');
  }
  return res.json();
}

/** U-07: Soft-delete training record (Admin only) */
export async function deleteTrainingRecord(recordId, token) {
  const res = await authFetch(
    `${API_BASE}/records/${recordId}`,
    {
      method: 'DELETE'
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to delete training record');
  }
  return res.json();
}

/** U-07: Restore soft-deleted training record (Admin only) */
export async function restoreTrainingRecord(recordId, token) {
  const res = await authFetch(
    `${API_BASE}/records/${recordId}/restore`,
    {
      method: 'POST'
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to restore training record');
  }
  return res.json();
}

/** U-07: Disable staff account */
export async function disableUser(userId, token) {
  const res = await authFetch(
    `${API_BASE}/users/${userId}/disable`,
    {
      method: 'PUT'
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to disable user account');
  }
  return res.json();
}

/** U-07: Re-enable staff account */
export async function reenableUser(userId, token) {
  const res = await authFetch(
    `${API_BASE}/users/${userId}/re-enable`,
    {
      method: 'PUT'
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to re-enable user account');
  }
  return res.json();
}

/** Admin Certificate Reissue with mandatory reason */
export async function reissueCertificate(certId, data, token) {
  const res = await authFetch(
    `${API_BASE}/certifications/${certId}/reissue`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to reissue certificate');
  }
  return res.json();
}

/** Trainer / Admin closes a quiz session to unlock per-question review (SEC-26, U-12) */
export async function closeQuizApi(quizId, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/quizzes/${quizId}/close`,
    { method: 'POST' },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to close quiz session');
  }
  return res.json();
}

/** Trainer / Admin approves a quiz for student deployment (GAM-01, SEC-26, U-12) */
export async function approveQuizApi(quizId, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/quizzes/${quizId}/approve`,
    { method: 'POST' },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to approve quiz');
  }
  return res.json();
}

/** Lists all gamified breakout teams for a training session (GAM-03) */
export async function fetchSessionTeams(sessionId, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/sessions/${sessionId}/teams`,
    { method: 'GET' },
    token
  );
  if (!res.ok) {
    return [];
  }
  return res.json();
}

/** Creates a breakout team within a session (GAM-03) */
export async function createSessionTeam(sessionId, teamName, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/sessions/${sessionId}/teams`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ team_name: teamName })
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to create team');
  }
  return res.json();
}

/** Adds or updates a trainee's gamified breakout team assignment (GAM-03) */
export async function assignTraineeToTeam(teamId, traineeId, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/teams/${teamId}/members`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ trainee_id: traineeId })
    },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to assign trainee to team');
  }
  return res.json();
}

/** Removes a trainee from a breakout team (GAM-03) */
export async function removeTraineeFromTeam(teamId, traineeId, token) {
  const res = await authFetch(
    `${API_BASE}/gamification/teams/${teamId}/members/${traineeId}`,
    { method: 'DELETE' },
    token
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Failed to remove trainee from team');
  }
  return res.json();
}

export async function submitQuizAnswers(traineeId, quizId, answers, token) {
  try {
    const res = await authFetch(`${API_BASE}/gamification/submit-quiz`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        trainee_id: traineeId, quiz_id: quizId, answers,
        attempt_id: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `att-${Date.now()}`
      })
    }, token);
    if (res.ok) { const d = await res.json(); return { score: d.last_score ?? 0 }; }
  } catch (err) { console.warn('submitQuizAnswers failed:', err); }
  return null;
}

export async function fetchAdminCourses(token) {
  try { const r = await authFetch(`${API_BASE}/users/courses`, {}, token); if (r.ok) return await r.json(); } catch {}
  return [];
}
export async function fetchTrainerPrograms(userId, token) {
  try { const r = await authFetch(`${API_BASE}/users/${userId}/programs`, {}, token); if (r.ok) return await r.json(); } catch {}
  return [];
}
export async function saveTrainerPrograms(userId, courseIds, token) {
  try {
    const r = await authFetch(`${API_BASE}/users/${userId}/programs`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ course_ids: courseIds })
    }, token);
    return r.ok;
  } catch { return false; }
}


export async function fetchQuizAttemptsApi(token, quizId = null) {
  try {
    const qs = quizId ? `?quiz_id=${encodeURIComponent(quizId)}` : "";
    const res = await authFetch(`${API_BASE}/gamification/quiz-attempts${qs}`, {}, token);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn("API fallback for quiz attempts:", err);
  }
  return [];
}
